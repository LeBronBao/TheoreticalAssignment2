package homework;

public class BalanceInquiry extends Trasaction {
	public BalanceInquiry(int userAccountNumber,Screen atmScreen,
			BankDatabase atmBankDatabase){
		super(userAccountNumber,atmScreen, atmBankDatabase);
	}
	@Override
	public void execute(){
		BankDatabase bankDatabase = getBankDatabase();
		Screen screen = getScreen();
		double availableBalance = bankDatabase.getAvailableBalance( getAccountNumber() );
		double totalBalance = bankDatabase.getTotalBalance(getAccountNumber());
		
		screen.displayMessageLine("\nBalance Information: ");
		screen.displayMessage("-Available balance: ");
		screen.displayDollarAmount(availableBalance);
		screen.displayMessage("\nTotal balance: ");
		screen.displayDollarAmount(totalBalance);
		screen.displayMessageLine("");
		
		
		
		
	}
	
	
	
}
