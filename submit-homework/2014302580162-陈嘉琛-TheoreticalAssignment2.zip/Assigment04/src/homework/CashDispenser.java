package homework;

public class CashDispenser {
	private final static int INITIAL_COUNT = 500;
	private int count; // number of $20 bills remaining
	
	public CashDispenser(){
		count = INITIAL_COUNT;
	}
	public void dispenseCash(int amount){
		int billsRequest = amount;
		count -= billsRequest;
	}
	public boolean isSufficientCashAvailable(int amount){
		int billsRequest = amount;
		if(count>=billsRequest){
			return true;
		}
		else
			return false;
	}
	
	
	
}
