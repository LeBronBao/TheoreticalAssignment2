package homework;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class MainGUI2014302580162 extends JFrame implements ActionListener{
	private JButton enter = new JButton("enter");
	private JButton inquiry = new JButton("Balance inquiry");
	private JButton deposit = new JButton("deposit");
	private JButton withdrawal = new JButton("Withdrawal");
	private BankDatabase bankDatabase = new BankDatabase();
	private int tempAccount;
	private int pin;

	public MainGUI2014302580162(){
		load();
	}
	private void load() {
		GridLayout grid = new GridLayout(2,2);
		this.setLayout(grid);
		this.setTitle("ATM");
		this.setSize(600, 600);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setVisible(true);
		
		this.enter.setActionCommand("enter");
		this.inquiry.setActionCommand("Balance inquiry");
		this.deposit.setActionCommand("Deposit");
		this.withdrawal.setActionCommand("Withdrawal");
		
		enter.addActionListener(this);
		inquiry.addActionListener(this);
		deposit.addActionListener(this);
		withdrawal.addActionListener(this);
		
		this.add(enter);
		this.add(inquiry);
		this.add(deposit);
		this.add(withdrawal);
		
		inquiry.setEnabled(false);
		deposit.setEnabled(false);
		withdrawal.setEnabled(false);
	}
	public static void main(String[] args){
		MainGUI2014302580162 gui = new MainGUI2014302580162();
		
	}
	public void actionPerformed(ActionEvent e){
		String command = e.getActionCommand();
		if(command.equals("enter")){
			this.enter.setText("enter");
			String temp = JOptionPane.showInputDialog(this,"Please enter your account");
			 tempAccount = Integer.parseInt(temp);
			String temp2 = JOptionPane.showInputDialog(this,"Please enter your pin");
			 pin = Integer.parseInt(temp2);
			boolean userAuthenticated = bankDatabase.authenticateUser(tempAccount, pin);
			if(!userAuthenticated){
				JOptionPane.showMessageDialog(this, "Invalid account number or PIN. Please try again.");
			}
		
			else{
				JOptionPane.showMessageDialog(this,"Welcome");
				inquiry.setEnabled(true);
				deposit.setEnabled(true);
				withdrawal.setEnabled(true);
				enter.setEnabled(false);
			
			}
		}
		else if(command.equals("Balance inquiry")){
			JOptionPane.showMessageDialog(this,"Your balance is:"+bankDatabase.getTotalBalance(tempAccount));
		}
		else if(command.equals("Deposit")){
			double amount = Double.parseDouble(JOptionPane.showInputDialog(this,"Enter the amount you want to deposit"));
			bankDatabase.credit(tempAccount, amount);
		}
		else if(command.equals("Withdrawal")){
			double amount = Double.parseDouble(JOptionPane.showInputDialog(this,"Enter the amount you want to withdrawal"));
			if(amount<bankDatabase.getTotalBalance(tempAccount)){
				bankDatabase.debit(tempAccount, amount);
			}else{
				JOptionPane.showMessageDialog(this, "Your balance is not enough");
			}
		}
		
}
	
}
